Playlist Studio 3.0 — Fluent Dark

This build kit extends the Playlist Studio 2.8.x editor workflow rather than replacing it with a dashboard.

UI direction selected: Option 1 — Fluent Dark.

Key UI changes:
- compact Windows-style command bar
- Open / Import URL / Save / Sources / Xtream
- familiar category rail + channel table + player/inspector
- no dashboard KPI wall or persistent navigation sidebar
- Ctrl+A selects all visible channels in the current category
- double-click video fullscreen and Esc returns via the existing player implementation
- bundled LibVLC is downloaded and SHA-256 verified during build

GitHub integration:
- GitHub sign-in, repository selection, Pull, and Push have been removed from Playlist Studio.
- Use Open / Import URL / Save / Save As for playlist editing. GitHub remains available externally as a normal web repository.

Build:
1. Run BUILD-WINDOWS.cmd on Windows 10/11 x64.
2. The script installs Pillow, openpyxl and PyInstaller.
3. It downloads VLC 3.0.23 from VideoLAN and verifies the SHA-256 before packaging.
4. The final EXE is placed beside this script.


