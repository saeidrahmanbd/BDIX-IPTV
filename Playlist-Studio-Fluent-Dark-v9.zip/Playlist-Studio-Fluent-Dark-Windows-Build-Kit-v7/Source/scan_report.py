"""Export scan evidence as a standalone Excel workbook."""
import os
import tempfile
from pathlib import Path


def export_excel(path, data):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
    book = Workbook()
    sheet = book.active
    sheet.title = 'Stream scan'
    rows = data['results']
    sheet.append(['Playlist Studio — Stream scan'])
    sheet.append(['Scan started', data['scan_started']])
    sheet.append(['Scan state', data['scan_state']])
    sheet.append(['Checked', len(rows), 'Scope total', data['scope_total']])
    sheet.append(['Dead', sum(r['status'] == 'Dead' for r in rows), 'Response', sum(r['status'] == 'Responsive' for r in rows), 'Unverified', sum(r['status'] == 'Unverified' for r in rows), 'Restricted', sum(r['status'] == 'Restricted' for r in rows)])
    sheet.append([data['note']])
    sheet.merge_cells('A6:E6')
    sheet['A6'].alignment = Alignment(wrap_text=True, vertical='top')
    sheet.row_dimensions[6].height = 44
    sheet.append([])
    sheet.append(['Channel', 'Category', 'Status', 'Details', 'Seconds'])
    colors = {'Dead': 'FCE4E6', 'Response': 'DDF3E8', 'Responsive': 'DDF3E8', 'Restricted': 'FFF1CC', 'Unreachable': 'FFF1CC', 'Unavailable': 'FFF1CC'}
    for record in rows:
        status='Response' if record['status']=='Responsive' else record['status']
        sheet.append([record['channel'], record['category'], status, record['detail'], record['seconds']])
        row = sheet.max_row
        sheet.cell(row, 5).number_format = '0.00'
        sheet.cell(row, 3).fill = PatternFill('solid', fgColor=colors.get(record['status'], 'EDF1F7'))
        sheet.row_dimensions[row].height = 42
        for cell in sheet[row]:
            cell.alignment = Alignment(vertical='top', wrap_text=True)
    for row in sheet:
        for cell in row:
            if isinstance(cell.value, str):
                cell.value = ILLEGAL_CHARACTERS_RE.sub('', cell.value)
                cell.data_type = 's'
            cell.font = Font(name='Calibri', size=11, color='172B42')
    sheet['A1'].font = Font(name='Calibri', size=19, bold=True, color='172B42')
    for cell in sheet[8]:
        cell.fill = PatternFill('solid', fgColor='172B42')
        cell.font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
    for column, width in zip('ABCDE', [32, 26, 19, 85, 12]):
        sheet.column_dimensions[column].width = width
    sheet.freeze_panes = 'A9'
    sheet.auto_filter.ref = f'A8:E{max(8, sheet.max_row)}'
    sheet.sheet_view.showGridLines = False
    sheet.print_title_rows = '1:8'
    target = Path(path)
    fd, temporary = tempfile.mkstemp(suffix='.xlsx', dir=target.parent)
    os.close(fd)
    try:
        book.save(temporary)
        os.replace(temporary, target)
    finally:
        book.close()
        if os.path.exists(temporary):
            os.unlink(temporary)
