"""Fullscreen uses a separate native render surface; Tk layout never moves."""
import ctypes as C
from ctypes import wintypes as W
import tkinter as tk
from tkinter import ttk

class NativeVideoSurface:
    def __init__(self,container):
        self.container=container;self.current=container;self.closed=False;self.api=C.WinDLL('user32',use_last_error=True)
        signatures={
            'CreateWindowExW':(W.HWND,[W.DWORD,W.LPCWSTR,W.LPCWSTR,W.DWORD,C.c_int,C.c_int,C.c_int,C.c_int,W.HWND,W.HMENU,W.HINSTANCE,C.c_void_p]),
            'GetParent':(W.HWND,[W.HWND]),'SetParent':(W.HWND,[W.HWND,W.HWND]),
            'GetClientRect':(W.BOOL,[W.HWND,C.POINTER(W.RECT)]),
            'SetWindowPos':(W.BOOL,[W.HWND,W.HWND,C.c_int,C.c_int,C.c_int,C.c_int,W.UINT]),
            'DestroyWindow':(W.BOOL,[W.HWND]),
        }
        for name,(result,args) in signatures.items():fn=getattr(self.api,name);fn.restype=result;fn.argtypes=args
        # This plain native child is not managed by Tk. Fullscreen cannot change
        # the Tk frame's requested size or push its packed controls off-screen.
        self.hwnd=self.api.CreateWindowExW(0,'STATIC','Playlist Studio video',0x54000004,0,0,1,1,container.winfo_id(),None,None,None)
        if not self.hwnd:raise C.WinError(C.get_last_error())
        self.resize()
    def size(self):
        rect=W.RECT();self.api.GetClientRect(self.current.winfo_id(),C.byref(rect));return max(1,rect.right-rect.left),max(1,rect.bottom-rect.top)
    def resize(self):
        if self.closed:return
        width,height=self.size();self.api.SetWindowPos(self.hwnd,None,0,0,width,height,0x54)
    def reparent(self,container):
        C.set_last_error(0);self.api.SetParent(self.hwnd,container.winfo_id());error=C.get_last_error()
        if error:raise C.WinError(error)
        self.current=container;self.resize()
    def raise_widget(self,widget):
        if widget.winfo_exists():self.api.SetWindowPos(widget.winfo_id(),None,0,0,0,0,0x53)
    def close(self):
        if not self.closed:self.closed=True;self.api.DestroyWindow(self.hwnd)

class FullscreenVideo:
    def __init__(self,owner,surface,on_close,build_controls,on_resize):
        self.surface=surface;self.closed=False;self.api=surface.api;self.hwnd=surface.hwnd
        self.window=tk.Toplevel(owner);self.window.title('Playlist Studio · Full screen');self.window.configure(bg='#03060c');self.window.geometry(f'800x500+{owner.winfo_rootx()}+{owner.winfo_rooty()}');self.window.attributes('-fullscreen',True)
        self.bar=ttk.Frame(self.window,padding=(16,10));build_controls(self.bar)
        self.host=tk.Frame(self.window,bg='#03060c');self.host.pack(fill='both',expand=True);self.window.update_idletasks()
        self.window.bind('<Escape>',lambda e:(on_close(),'break')[1]);self.window.bind('<F11>',lambda e:(on_close(),'break')[1]);self.window.protocol('WM_DELETE_WINDOW',on_close)
        try:surface.reparent(self.host)
        except Exception:self.window.destroy();raise
        self.host.bind('<Configure>',lambda e:self.resize(on_resize));self.resize(on_resize);self.window.lift();self.window.focus_set()
    def resize(self,callback):
        if not self.closed:self.surface.resize();callback()
    def close(self):
        if self.closed:return
        # Use the CURRENT embedded frame size, including a resize while away.
        self.surface.container.update_idletasks();self.surface.reparent(self.surface.container);self.closed=True;self.window.destroy()
