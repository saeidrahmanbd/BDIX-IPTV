from pathlib import Path
p=Path(__file__).with_name('playlist_studio.py');s=p.read_text(encoding='utf-8')
a="self.workspace=ttk.Notebook(middle);self.workspace.pack(fill='both',expand=True);self.channel_tab=ttk.Frame(self.workspace);self.player_tab=ttk.Frame(self.workspace);self.workspace.add(self.channel_tab,text='CHANNELS');self.workspace.add(self.player_tab,text='PLAYER');ttk.Label(self.player_tab,text='Select a channel, then choose ▶ Play.',style='Muted.TLabel',padding=24).pack(anchor='w')"
assert a in s;s=s.replace(a,"self.channel_tab=ttk.Frame(middle);self.channel_tab.pack(fill='both',expand=True)")
a="        logo=ttk.Frame(self.form);logo.pack"
assert a in s;s=s.replace(a,"        self.details_canvas=canvas;self.player_host=ttk.Frame(self.form);self.player_host.pack(fill='x')\n        logo=ttk.Frame(self.form);logo.pack")
a="""        if self.player is None:
            for child in self.player_tab.winfo_children():child.destroy()
            self.player=PlayerPane(self.player_tab,self);self.player.pack(fill='both',expand=True)
        self.workspace.select(self.player_tab);self.update_idletasks();self.player.play(self.doc.channel(ids[0]))"""
b="""        if self.player is None:
            self.player=PlayerPane(self.player_host,self,compact=True);self.player.pack(fill='x')
        self.update_idletasks();self.details_canvas.yview_moveto(0);self.player.play(self.doc.channel(ids[0]))"""
assert a in s;s=s.replace(a,b).replace('2.1','2.2').replace('to watch in the PLAYER tab.','to watch at the top of the right-hand details panel.').replace('Playback continues in the CHANNELS tab.','The channel list stays visible while you watch. Scroll the details panel for metadata and the channel logo.')
p.write_text(s,encoding='utf-8')
p=Path(__file__).with_name('studio_extras.py');s=p.read_text(encoding='utf-8').replace('2.1','2.2');start=s.index('class PlayerPane');head=s[:start];tail=s[start:]
tail=tail.replace('def __init__(self,parent,app):','def __init__(self,parent,app,compact=False):',1).replace('super().__init__(parent,padding=12)','super().__init__(parent,padding=(0,6) if compact else 12)',1)
tail=tail.replace("style='Title.TLabel',wraplength=500","font=('Segoe UI Semibold',13 if compact else 17),wraplength=500",1).replace("height=70,highlightbackground","height=170 if compact else 70,highlightbackground",1)
tail=tail.replace('Playback continues when you return to the channel list. Stop ends it.','Use the channel list to choose another stream. Scroll down for channel details.')
p.write_text(head+tail,encoding='utf-8')
