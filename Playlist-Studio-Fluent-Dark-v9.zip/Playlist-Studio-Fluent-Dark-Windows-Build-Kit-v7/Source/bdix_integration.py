"""BDIX-IPTV integration for Playlist Studio.
Xtream Codes login/import and playlist audit rules.
No automatic destructive changes are made; candidates are shown before commit.
"""
from __future__ import annotations
import base64, json, re, urllib.parse, urllib.request, urllib.error
from dataclasses import dataclass, field
from pathlib import Path
from playlist_core import Playlist, Channel, PlaylistError, save_atomic

UA='PlaylistStudio/BDIX-IPTV/3.0'

def _request(url, method='GET', data=None, headers=None, timeout=25):
    h={'User-Agent':UA,'Accept':'application/json,*/*'}; h.update(headers or {})
    req=urllib.request.Request(url,data=data,headers=h,method=method)
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return r.status, r.headers, r.read(30*1024*1024+1)

def _json(url, headers=None):
    status,_,raw=_request(url,headers=headers)
    if len(raw)>30*1024*1024: raise PlaylistError('Response exceeds 30 MB.')
    return json.loads(raw.decode('utf-8'))

@dataclass
class XtreamConfig:
    server:str=''
    username:str=''
    password:str=''
    profile_name:str=''

def normalize_server(server):
    server=server.strip().rstrip('/')
    if not server: raise PlaylistError('Xtream server URL is required.')
    p=urllib.parse.urlsplit(server if '://' in server else 'http://'+server)
    if p.scheme not in ('http','https') or not p.hostname: raise PlaylistError('Enter a valid Xtream server URL.')
    return f'{p.scheme}://{p.netloc}'

def xtream_login(cfg:XtreamConfig):
    base=normalize_server(cfg.server)
    q=urllib.parse.urlencode({'username':cfg.username,'password':cfg.password})
    data=_json(base+'/player_api.php?'+q)
    info=data.get('user_info',{})
    if info.get('auth') not in (1,'1',True): raise PlaylistError('Xtream login failed. Check server, username and password.')
    return base,data

def xtream_m3u_url(cfg):
    base=normalize_server(cfg.server)
    q=urllib.parse.urlencode({'username':cfg.username,'password':cfg.password,'type':'m3u_plus','output':'ts'})
    return base+'/get.php?'+q

def channel_key(ch:Channel):
    tvgid=(ch.attrs.get('tvg-id') or '').strip().casefold()
    url=re.sub(r'[?#].*$','',ch.url.strip()).rstrip('/').casefold()
    name=re.sub(r'[^a-z0-9]+','',ch.name.casefold())
    return tvgid or url or name

def normalized_name(name):
    return re.sub(r'\s+',' ',re.sub(r'[^\w&+\- ]+',' ',name,flags=re.UNICODE)).strip().casefold()

def audit_playlist(doc:Playlist):
    rows=[]; seen_chno={}; seen_key={}
    trusted_logo_hosts=("raw.githubusercontent.com", "github.com", "gitlab.com")
    for ch in doc.ordered():
        flags=[]
        tvgid=(ch.attrs.get('tvg-id') or '').strip(); chno=(ch.attrs.get('tvg-chno') or '').strip(); logo=(ch.attrs.get('tvg-logo') or '').strip(); url=ch.url.strip()
        group=(ch.attrs.get('group-title') or doc.category(ch.category_id).name or '').strip()
        is_backup=('backup' in group.casefold()) or bool(re.search(r'\[\s*backup(?:\s*\d+)?\s*\]', ch.name, re.I))
        if not tvgid: flags.append('missing-tvg-id')
        if not chno:
            flags.append('missing-backup-tvg-chno' if is_backup else 'missing-tvg-chno')
        elif not is_backup:
            if chno in seen_chno: flags.append('duplicate-tvg-chno')
            else: seen_chno[chno]=ch.name
        # Backups intentionally share the same tvg-id/name as their primary. Only flag
        # duplicate keys among non-backup entries or identical URLs within a cluster.
        key=channel_key(ch)
        if key:
            if is_backup:
                backup_url_key=(key, re.sub(r'[?#].*$','',url).rstrip('/').casefold())
                if backup_url_key in seen_key: flags.append('duplicate-backup-url')
                else: seen_key[backup_url_key]=ch.name
            elif key in seen_key: flags.append('duplicate-channel')
            else: seen_key[key]=ch.name
        if not logo: flags.append('missing-logo')
        else:
            host=(urllib.parse.urlsplit(logo).hostname or '').casefold()
            if host and host not in trusted_logo_hosts: flags.append('external-logo')
        if not url: flags.append('missing-url')
        low=url.casefold()
        if any(x in low for x in ('/proxy','proxy.php','token=','?token','vod/','/movie/','/series/')): flags.append('review-url')
        rows.append({'channel':ch,'flags':flags,'is_backup':is_backup})
    return rows

@dataclass
class Candidate:
    channel:Channel
    reason:str
    source:str

def discover_new(existing:Playlist, incoming:Playlist, allowed_categories=('Bangladesh Music','Bangladesh Movies','India Music','India Movies','Music','Movies')):
    keys={channel_key(c) for c in existing.ordered() if channel_key(c)}
    names={normalized_name(c.name) for c in existing.ordered()}
    out=[]
    for ch in incoming.ordered():
        k=channel_key(ch); n=normalized_name(ch.name)
        if (k and k in keys) or (n and n in names): continue
        cat=incoming.category(ch.category_id).name
        low=(cat+' '+ch.name).casefold()
        # Conservative auto-accept rules requested for BDIX project.
        if any(x in low for x in ('news','sport','sports','relig','religion','kids','cartoon')): continue
        if any(x in low for x in ('proxy','token','vod','series')): continue
        is_backup='backup' in low or 'backup' in (ch.attrs.get('group-title','').casefold())
        is_media=any(x in low for x in ('music','movie','cinema','film'))
        # Backup streams are eligible independently of the Music/Movie category rule.
        if not is_media and not is_backup: continue
        out.append(Candidate(ch,'backup-candidate' if is_backup else 'new-candidate',cat))
        if k: keys.add(k)
        if n: names.add(n)
    return out

def import_candidates(existing:Playlist,candidates:list[Candidate]):
    added=[]
    for item in candidates:
        src=item.channel; cid=existing.ensure_category(src.attrs.get('group-title') or item.source or 'Uncategorized')
        ch=Channel(src.name,src.url,cid,dict(src.attrs),list(src.directives),src.duration)
        existing.channels.append(ch);added.append(ch)
    return added
