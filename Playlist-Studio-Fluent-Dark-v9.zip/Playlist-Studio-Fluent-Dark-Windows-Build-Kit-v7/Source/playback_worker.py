"""Keep native decoder/TLS faults outside the playlist editor process."""
import multiprocessing as mp
import queue
import threading
import time


def run_player(pipe, hwnd, play, settings):
    from vlc_engine import VLCPlayer
    engine = None
    try:
        engine = VLCPlayer(hwnd)
        engine.volume(settings['volume'])
        engine.mute(settings['mute'])
        generation, url, headers = play
        engine.play(url, headers)
        view = settings['view']
        applied = None
        while True:
            if pipe.poll(.15):
                command, value = pipe.recv()
                if command == 'close':
                    break
                if command == 'view':
                    view = value
                elif command in ('pause', 'stop', 'volume', 'mute', 'seek'):
                    if command == 'stop':
                        engine.stop()
                    else:
                        getattr(engine, command)(value)
            state = engine.state()
            if state in (3, 4) and applied != view:
                engine.view(*view)
                applied = view
            pipe.send(('state', generation, state, engine.time(), engine.length()))
    except (EOFError, BrokenPipeError):
        pass
    except Exception as exc:
        try:
            pipe.send(('error', play[0], str(exc)))
        except (EOFError, BrokenPipeError, OSError):
            pass
    finally:
        if engine:
            engine.close()
        pipe.close()


class PlaybackSupervisor(threading.Thread):
    def __init__(self, hwnd, commands, events):
        super().__init__(daemon=True, name='PlaybackSupervisor')
        self.hwnd, self.commands, self.events = hwnd, commands, events
        self.process = self.pipe = None
        self.generation = 0
        self.settings = {'volume': 70, 'mute': False, 'view': ('Fit', 1, 1)}
        self.last_response = 0

    def dispose(self):
        process, pipe = self.process, self.pipe
        self.process = self.pipe = None
        if process:
            if process.is_alive():
                # Bounded disposal: a blocked TLS shutdown must not hold up switching.
                try:
                    pipe.send(('close', None))
                except (BrokenPipeError, EOFError, OSError):
                    pass
                process.join(.35)
                if process.is_alive():
                    process.terminate()
                    process.join(1)
            process.close()
        if pipe:
            pipe.close()

    def run(self):
        try:
            while True:
                try:
                    command, value = self.commands.get(timeout=.05)
                    # Keep only the latest channel request in a rapid-click burst.
                    batch = [(command, value)]
                    while True:
                        try:
                            batch.append(self.commands.get_nowait())
                        except queue.Empty:
                            break
                    last_play = max((i for i, x in enumerate(batch) if x[0] == 'play'), default=-1)
                    for i, (command, value) in enumerate(batch):
                        if command == 'close':
                            return
                        if command in self.settings:
                            self.settings[command] = value
                        if command == 'play':
                            if i != last_play:
                                continue
                            self.dispose()
                            self.generation = value[0]
                            context = mp.get_context('spawn')
                            self.pipe, child = context.Pipe()
                            self.process = context.Process(target=run_player, args=(child, self.hwnd, value, dict(self.settings)), daemon=True)
                            self.process.start()
                            child.close()
                            self.last_response = time.monotonic()
                        elif command == 'stop':
                            self.dispose()
                            self.events.put(('state', self.generation, 5, 0, 0))
                        elif self.pipe:
                            try:
                                self.pipe.send((command, value))
                            except (BrokenPipeError, EOFError, OSError):
                                pass
                except queue.Empty:
                    pass
                if self.pipe:
                    try:
                        while self.pipe.poll():
                            event = self.pipe.recv()
                            self.last_response = time.monotonic()
                            self.events.put(event)
                    except (BrokenPipeError, EOFError, OSError):
                        pass
                if self.process and (not self.process.is_alive() or time.monotonic() - self.last_response > 15):
                    self.dispose()
                    self.events.put(('state', self.generation, 7, 0, 0))
                    self.events.put(('error', self.generation, 'The playback engine stopped responding. Your playlist is safe. Choose another channel or press Retry.'))
        except Exception as exc:
            self.events.put(('fatal', 'Playback could not start: ' + str(exc)))
        finally:
            self.dispose()
