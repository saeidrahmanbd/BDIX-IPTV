"""Hybrid Studio UI for Playlist Studio 3.0.

Keeps the existing controller-facing widget attributes intact while presenting a
Windows-style IPTV operations workspace: navigation, dashboard KPIs, channel
workbench, inspector and embedded player.
"""
import tkinter as tk
from tkinter import ttk
from studio_extras import PlayerPane, show_info
from bdix_integration import audit_playlist
from tkinter import filedialog, messagebox

BG='#071116'; SIDEBAR='#0a171d'; PANEL='#0d1d24'; FIELD='#09171d'
INK='#edf8fa'; MUTED='#91aab4'; ACCENT='#42e6d2'; LINE='#203a44'
BLUE='#4fa7ff'; WARN='#e7c66d'; RED='#ff8f9a'; GREEN='#66e0a0'


def styles(app):
    s=ttk.Style(app)
    s.theme_use('clam')
    s.configure('.',background=PANEL,foreground=INK,font=('Segoe UI',10))
    s.configure('TFrame',background=PANEL); s.configure('Shell.TFrame',background=BG)
    s.configure('TLabel',background=PANEL,foreground=INK)
    s.configure('Muted.TLabel',background=PANEL,foreground=MUTED)
    s.configure('Title.TLabel',background=PANEL,foreground=INK,font=('Segoe UI Semibold',18))
    s.configure('Section.TLabel',background=PANEL,foreground=INK,font=('Segoe UI Semibold',11))
    s.configure('TButton',background='#17303a',foreground=INK,borderwidth=0,padding=(11,7))
    s.map('TButton',background=[('active','#224652'),('disabled','#10242b')])
    s.configure('Accent.TButton',background=ACCENT,foreground='#062125',font=('Segoe UI Semibold',10))
    s.map('Accent.TButton',background=[('active','#75f1e3')])
    s.configure('Quiet.TButton',background=PANEL,foreground=MUTED,padding=(9,6))
    s.map('Quiet.TButton',foreground=[('active',ACCENT)])
    s.configure('Nav.TButton',background=SIDEBAR,foreground=MUTED,anchor='w',padding=(14,9),font=('Segoe UI',10))
    s.map('Nav.TButton',background=[('active','#132d36'),('selected','#143d40')],foreground=[('active',INK),('selected',ACCENT)])
    s.configure('KPI.TFrame',background='#10242c',borderwidth=1,relief='solid',bordercolor=LINE)
    s.configure('KPIValue.TLabel',background='#10242c',foreground=INK,font=('Segoe UI Semibold',19))
    s.configure('KPICaption.TLabel',background='#10242c',foreground=MUTED,font=('Segoe UI',9))
    s.configure('Card.TFrame',background=PANEL,borderwidth=1,relief='solid',bordercolor=LINE)
    s.configure('Treeview',rowheight=42,background=PANEL,fieldbackground=PANEL,foreground=INK,borderwidth=0)
    s.map('Treeview',background=[('selected','#1d4d61')],foreground=[('selected','#ffffff')])
    s.configure('Treeview.Heading',background='#132a33',foreground='#bfd2d8',padding=(8,10),font=('Segoe UI Semibold',10))
    s.map('Treeview.Heading',background=[('active','#1b3944')])
    s.configure('Category.Treeview',rowheight=39)
    s.map('Category.Treeview',background=[('selected','#16494a')],foreground=[('selected',ACCENT)])
    s.configure('Filter.TRadiobutton',background=FIELD,foreground=MUTED,padding=(12,8),borderwidth=1,bordercolor=LINE)
    s.map('Filter.TRadiobutton',background=[('selected','#123e43'),('active','#17323b')],foreground=[('selected',ACCENT)])
    s.configure('TEntry',fieldbackground=FIELD,foreground=INK,insertcolor=INK,bordercolor=LINE,padding=7)
    s.configure('TCombobox',fieldbackground=FIELD,foreground=INK,arrowcolor=INK,padding=6)
    s.map('TCombobox',fieldbackground=[('readonly',FIELD)],foreground=[('readonly',INK)])
    s.configure('TNotebook',background=PANEL,borderwidth=0)
    s.configure('TNotebook.Tab',background=FIELD,foreground=MUTED,padding=(15,9))
    s.map('TNotebook.Tab',background=[('selected',LINE)],foreground=[('selected',ACCENT)])
    s.configure('TSeparator',background=LINE)
    s.configure('Vertical.TScrollbar',background=LINE,troughcolor=PANEL,arrowcolor=MUTED,borderwidth=0)
    s.configure('Horizontal.TScrollbar',background=LINE,troughcolor=PANEL,arrowcolor=MUTED,borderwidth=0)


def _nav(app, label, command):
    b=ttk.Button(app.nav_frame,text=label,style='Nav.TButton',command=command)
    b.pack(fill='x',pady=1)
    app.nav_buttons[label]=b
    return b


def build(app):
    styles(app)
    root=ttk.Frame(app,style='Shell.TFrame'); root.pack(fill='both',expand=True)

    # Persistent left navigation.
    sidebar=tk.Frame(root,bg=SIDEBAR,width=206,highlightthickness=0)
    sidebar.pack(side='left',fill='y'); sidebar.pack_propagate(False)
    app.nav_frame=sidebar; app.nav_buttons={}
    brand=tk.Frame(sidebar,bg=SIDEBAR); brand.pack(fill='x',padx=16,pady=(18,18))
    mark=tk.Label(brand,text='▶',bg=ACCENT,fg='#05272a',font=('Segoe UI Semibold',16),padx=8,pady=3);mark.pack(side='left')
    tk.Label(brand,text='Playlist Studio',bg=SIDEBAR,fg=INK,font=('Segoe UI Semibold',15)).pack(side='left',padx=9)
    tk.Label(sidebar,text='HYBRID STUDIO 3.0',bg=SIDEBAR,fg=ACCENT,font=('Segoe UI Semibold',8)).pack(anchor='w',padx=17,pady=(0,9))
    _nav(app,'⌂  Dashboard',lambda: app.set_view('dashboard') if hasattr(app,'set_view') else None)
    _nav(app,'▦  Channels',lambda: app.set_view('channels') if hasattr(app,'set_view') else None)
    _nav(app,'◈  Audit',app.bdix_audit)
    _nav(app,'✦  New Channels',app.find_new_channels)
    _nav(app,'↻  Backups',lambda: app.set_view('channels') if hasattr(app,'set_view') else None)
    _nav(app,'◉  Logos & EPG',lambda: app.set_view('channels') if hasattr(app,'set_view') else None)
    tk.Frame(sidebar,bg=LINE,height=1).pack(fill='x',padx=15,pady=14)
    tk.Label(sidebar,text='SOURCES',bg=SIDEBAR,fg='#69828c',font=('Segoe UI Semibold',8)).pack(anchor='w',padx=17,pady=(0,5))
    _nav(app,'Xtream',app.xtream_manager)
    _nav(app,'Import M3U',app.open_files)
    _nav(app,'Import URL',app.import_link)
    _nav(app,'▶  Player',app.play_selected)
    _nav(app,'⚙  Settings',app.settings)
    tk.Label(sidebar,text='SOURCE → AUDIT → REVIEW\n→ TEST → PUBLISH',bg=SIDEBAR,fg='#5f7983',justify='left',font=('Segoe UI',8)).pack(side='bottom',anchor='w',padx=17,pady=18)

    main=ttk.Frame(root,style='Shell.TFrame'); main.pack(side='left',fill='both',expand=True)
    top=ttk.Frame(main,padding=(20,14,20,10),style='Shell.TFrame'); top.pack(fill='x')
    left=ttk.Frame(top,style='Shell.TFrame'); left.pack(side='left')
    ttk.Label(left,text='Hybrid Studio',font=('Segoe UI Semibold',20),background=BG).pack(anchor='w')
    app.document_label=ttk.Label(left,text='Ready — open or import an M3U playlist',style='Muted.TLabel',background=BG);app.document_label.pack(anchor='w',pady=(2,0))
    right=ttk.Frame(top,style='Shell.TFrame');right.pack(side='right')
    ttk.Button(right,text='Open',command=app.open_files).pack(side='left',padx=3)
    ttk.Button(right,text='Import URL',command=app.import_link).pack(side='left',padx=3)
    ttk.Button(right,text='Save',command=app.save,style='Accent.TButton').pack(side='left',padx=3)
    ttk.Button(right,text='Xtream',command=app.xtream_manager).pack(side='left',padx=3)

    # KPI strip.
    kpi=ttk.Frame(main,style='Shell.TFrame');kpi.pack(fill='x',padx=20,pady=(0,12))
    app.stat_vars={}
    cards=[('channels','CHANNELS'),('issues','AUDIT ISSUES'),('logos','MISSING LOGOS'),('review','URL REVIEW'),('new','NEW / BACKUP')]
    for key,caption in cards:
        card=ttk.Frame(kpi,style='KPI.TFrame',padding=(14,9));card.pack(side='left',fill='x',expand=True,padx=(0,7))
        var=tk.StringVar(value='—');app.stat_vars[key]=var
        ttk.Label(card,textvariable=var,style='KPIValue.TLabel').pack(anchor='w')
        ttk.Label(card,text=caption,style='KPICaption.TLabel').pack(anchor='w')
    ttk.Button(kpi,text='↻ Refresh',command=app.refresh,style='Quiet.TButton').pack(side='right',padx=(3,0))

    work=ttk.Frame(main,style='Shell.TFrame');work.pack(fill='both',expand=True,padx=20,pady=(0,8))
    app.panes=ttk.Panedwindow(work,orient='horizontal');app.panes.pack(fill='both',expand=True)

    # Category rail.
    side=ttk.Frame(app.panes,padding=10,style='Card.TFrame');app.panes.add(side,weight=0)
    row=ttk.Frame(side);row.pack(fill='x',pady=(0,10));ttk.Label(row,text='PLAYLIST',style='Section.TLabel').pack(side='left');ttk.Button(row,text='+',width=2,command=app.add_category).pack(side='right')
    gb=ttk.Frame(side);gb.pack(fill='both',expand=True)
    app.groups=ttk.Treeview(gb,show='tree',selectmode='browse',style='Category.Treeview');app.groups.column('#0',width=185,minwidth=145)
    gs=ttk.Scrollbar(gb,orient='vertical',command=app.groups.yview);gs.pack(side='right',fill='y');app.groups.configure(yscrollcommand=gs.set);app.groups.pack(fill='both',expand=True)
    app.groups.bind('<<TreeviewSelect>>',app.select_group);app.groups.bind('<Double-1>',lambda e:app.rename_category());app.groups.bind('<ButtonPress-1>',lambda e:app.drag_start(e,'category'),add='+');app.groups.bind('<ButtonRelease-1>',app.drag_end,add='+');app.groups.bind('<B1-Motion>',app.drag_motion)
    for actions in [[('Rename',app.rename_category),('Delete',app.delete_category)],[('↑',lambda:app.move_category(-1)),('↓',lambda:app.move_category(1)),('A–Z',app.sort_categories)]]:
        rr=ttk.Frame(side);rr.pack(fill='x',pady=(7,0))
        for text,cmd in actions:ttk.Button(rr,text=text,command=cmd,style='Quiet.TButton').pack(side='left',fill='x',expand=True,padx=2)
    ttk.Label(side,text='Drag categories to reorder.\nDrop channels onto a category.',style='Muted.TLabel',wraplength=185).pack(anchor='w',pady=(12,4))

    # Channel workbench.
    middle=ttk.Frame(app.panes,padding=12,style='Card.TFrame');app.panes.add(middle,weight=4)
    heading=ttk.Frame(middle);heading.pack(fill='x',pady=(0,9))
    app.group_heading=ttk.Label(heading,text='All channels',style='Title.TLabel');app.group_heading.pack(side='left')
    ttk.Button(heading,text='▶  Play selected',command=app.play_selected,style='Accent.TButton').pack(side='right')
    toolbar=ttk.Frame(middle);toolbar.pack(fill='x',pady=(0,7))
    for title,cmd in [('+ Channel',app.add_channel),('Duplicate',app.duplicate),('Delete',app.delete_channels),('Move to…',app.move_selected),('↑',lambda:app.move_rows(-1)),('↓',lambda:app.move_rows(1)),('A–Z',app.sort_channels)]:ttk.Button(toolbar,text=title,command=cmd,style='Quiet.TButton').pack(side='left',padx=(0,4))
    searchrow=ttk.Frame(middle);searchrow.pack(fill='x',pady=(0,8))
    app.search=tk.StringVar();app.search.trace_add('write',app.search_changed)
    ttk.Label(searchrow,text='Search',style='Muted.TLabel').pack(side='left',padx=(0,7));app.search_entry=ttk.Entry(searchrow,textvariable=app.search);app.search_entry.pack(side='left',fill='x',expand=True)
    app.health_view=tk.StringVar(value='All channels')
    for title,value in [('All','All channels'),('Dead','Dead links only'),('Review','Needs review'),('Unscanned','Not scanned')]:ttk.Radiobutton(searchrow,text=title,value=value,variable=app.health_view,style='Filter.TRadiobutton',command=app.change_health_view).pack(side='left',padx=(5,0))
    app.channel_tab=ttk.Frame(middle);app.channel_tab.pack(fill='both',expand=True)
    table=ttk.Frame(app.channel_tab);table.pack(fill='both',expand=True)
    app.table=ttk.Treeview(table,columns=('name','group','health','url','epg','format'),displaycolumns=('name','group','health','url'),show='tree headings',selectmode='extended')
    app.table.column('#0',width=62,minwidth=62,stretch=False);app.table.heading('#0',text='▶')
    for key,label,width,minimum in [('name','Channel',205,135),('group','Group',120,90),('health','Status',105,90),('url','Stream URL',230,110),('epg','EPG ID',100,70),('format','Format',70,60)]:app.table.heading(key,text=label);app.table.column(key,width=width,minwidth=minimum,stretch=key in ('name','url'))
    sv=ttk.Scrollbar(table,orient='vertical',command=app.table.yview);sv.pack(side='right',fill='y');sh=ttk.Scrollbar(table,orient='horizontal',command=app.table.xview);sh.pack(side='bottom',fill='x');app.table.configure(yscrollcommand=sv.set,xscrollcommand=sh.set);app.table.pack(fill='both',expand=True)
    app.table.tag_configure('alternate',background='#0f262e');app.table.tag_configure('missing',foreground=RED);app.table.tag_configure('dead',foreground=RED);app.table.tag_configure('review',foreground=WARN);app.table.tag_configure('drop',background='#21534b',foreground='#c4fff0')
    app.table.bind('<<TreeviewSelect>>',app.select_channel);app.table.bind('<ButtonPress-1>',app.channel_press,add='+');app.table.bind('<ButtonRelease-1>',app.drag_end,add='+');app.table.bind('<B1-Motion>',app.drag_motion);app.table.bind('<Motion>',app.channel_hover);app.table.bind('<Delete>',lambda e:app.delete_channels());app.bind('<Escape>',lambda e:app.clear_drag())
    history=ttk.Frame(app.channel_tab);history.pack(fill='x',pady=(7,0));app.undo_button=ttk.Button(history,text='↶ Undo',command=app.undo,style='Quiet.TButton');app.undo_button.pack(side='right');app.redo_button=ttk.Button(history,text='↷ Redo',command=app.redo,style='Quiet.TButton');app.redo_button.pack(side='right',padx=4)
    app.empty=ttk.Label(app.channel_tab,text='',style='Muted.TLabel',wraplength=600);app.empty.pack(anchor='w',pady=(5,0))

    # Inspector + player.
    details=ttk.Frame(app.panes,padding=12,width=430,style='Card.TFrame');app.panes.add(details,weight=1);app.inspector=details
    app.player_host=ttk.Frame(details);app.player_host.pack(fill='x');app.player=PlayerPane(app.player_host,app,compact=True);app.player.pack(fill='x')
    ttk.Separator(details).pack(fill='x',pady=(8,9));ttk.Label(details,text='CHANNEL INSPECTOR',style='Section.TLabel').pack(anchor='w')
    app.selection_label=ttk.Label(details,text='Select one channel to edit.',style='Muted.TLabel');app.selection_label.pack(anchor='w',pady=(4,7))
    bottom=ttk.Frame(details);bottom.pack(side='bottom',fill='x',pady=(8,0));bottom.pack_configure(before=app.player_host)
    app.apply_button=ttk.Button(bottom,text='Apply changes',style='Accent.TButton',command=app.apply_channel);app.apply_button.pack(side='right',fill='x',expand=True);ttk.Button(bottom,text='Revert',command=app.revert_form,style='Quiet.TButton').pack(side='left',padx=(0,7))
    outer=ttk.Frame(details);outer.pack(fill='both',expand=True);canvas=tk.Canvas(outer,bg=PANEL,highlightthickness=0,width=370);scroll=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview);canvas.configure(yscrollcommand=scroll.set);scroll.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True);app.details_canvas=canvas;app.form=ttk.Frame(canvas);window=canvas.create_window((0,0),window=app.form,anchor='nw');app.form.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')));canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
    notebook=ttk.Notebook(app.form);notebook.pack(fill='both',expand=True);basic=ttk.Frame(notebook,padding=(2,8));advanced=ttk.Frame(notebook,padding=(2,8));notebook.add(basic,text='Essentials');notebook.add(advanced,text='EPG & advanced');notebook.bind('<<NotebookTabChanged>>',lambda e:canvas.yview_moveto(0))
    app.fields={};app.widgets=[]
    for key,label in [('name','Channel name'),('category','Group / category'),('tvg-logo','Logo URL or file path'),('tvg-id','EPG / channel ID'),('tvg-name','EPG display name'),('tvg-chno','Channel number'),('tvg-language','Language'),('tvg-country','Country'),('tvg-url','Channel EPG URL'),('tvg-shift','EPG time shift (hours)'),('duration','EXTINF duration (-1 for live TV)')]:
        parent=basic if key in ('name','category','tvg-logo') else advanced;ttk.Label(parent,text=label,style='Muted.TLabel').pack(anchor='w',pady=(5,3));var=tk.StringVar();var.trace_add('write',lambda *_:app.field_changed());app.fields[key]=var;w=ttk.Combobox(parent,textvariable=var,state='readonly') if key=='category' else ttk.Entry(parent,textvariable=var);w.pack(fill='x',pady=(0,3));app.widgets.append(w)
        if key=='category':
            app.category_combo=w;ttk.Label(parent,text='Stream URL',style='Muted.TLabel').pack(anchor='w',pady=(6,3));app.stream=app.textbox(parent,2);app.stream.bind('<<Modified>>',app.text_changed);rr=ttk.Frame(parent);rr.pack(fill='x',pady=(5,0));ttk.Button(rr,text='Copy link',command=app.copy_stream,style='Quiet.TButton').pack(side='left');ttk.Button(rr,text='Open link',command=app.open_stream,style='Quiet.TButton').pack(side='left',padx=5)
    logo=ttk.Frame(basic);logo.pack(fill='x',pady=8);app.logo_label=tk.Label(logo,text='TV',font=('Segoe UI Semibold',20),bg=FIELD,fg=ACCENT,width=5,height=2);app.logo_label.pack(side='left');lr=ttk.Frame(logo);lr.pack(side='left',padx=10);ttk.Button(lr,text='Refresh logo',command=lambda:app.logo_preview(True),style='Quiet.TButton').pack(anchor='w');app.logo_status=ttk.Label(lr,text='Select a channel to see its logo.',style='Muted.TLabel',wraplength=230);app.logo_status.pack(anchor='w',pady=5)
    ttk.Label(advanced,text='Playback directives',style='Muted.TLabel').pack(anchor='w',pady=(9,4));app.directives=app.textbox(advanced,4);app.directives.bind('<<Modified>>',app.text_changed);ttk.Label(advanced,text='#EXTVLCOPT, #KODIPROP and other options',style='Muted.TLabel',wraplength=330).pack(anchor='w',pady=4);ttk.Button(advanced,text='Additional attributes…',command=app.edit_attributes).pack(anchor='w',pady=8)
    app.advanced={}

    # Footer/status bar.
    footer=ttk.Frame(main,padding=(20,7),style='Shell.TFrame');footer.pack(side='bottom',fill='x');app.export_button=ttk.Button(footer,text='Export Excel…',command=lambda:_export_latest(app),state='disabled');app.export_button.pack(side='right');app.health_summary=ttk.Label(footer,text='No scan yet',foreground=ACCENT,background=BG);app.health_summary.pack(side='right',padx=14);app.status=tk.StringVar(value='Ready.');ttk.Label(footer,textvariable=app.status,style='Muted.TLabel',background=BG).pack(side='left',fill='x',expand=True)

    # Fit panes after the window has its final size.
    def fit_panes(event=None):
        width=app.panes.winfo_width()
        if width<800:return
        left=max(175,min(215,int(width*.15)));right=max(350,min(440,int(width*.29)));app.panes.sashpos(0,left);app.panes.sashpos(1,width-right)
        try:app.player.video.configure(height=max(150,min(280,app.panes.winfo_height()-300)))
        except Exception:pass
    app.panes.bind('<Configure>',fit_panes);app.panes.after_idle(fit_panes)

    def set_view(view):
        if view=='audit':return app.bdix_audit()
        if view=='channels':
            app.health_view.set('All channels');app.refresh_table();app.status.set('Channel workbench ready.')
        else:app.status.set('Dashboard — live playlist metrics are shown above.')
    app.set_view=set_view
    update_dashboard(app)


def update_dashboard(app):
    try:
        total=len(app.doc.channels)
        rows=audit_playlist(app.doc) if total else []
        issues=sum(bool(r['flags']) for r in rows)
        missing=sum('missing-logo' in r['flags'] for r in rows)
        review=sum('review-url' in r['flags'] for r in rows)
        new=0; backup=0
        for c in app.doc.channels:
            g=(c.attrs.get('group-title') or app.doc.category(c.category_id).name or '').casefold()
            if 'new channel' in g:new+=1
            if 'new backup' in g:backup+=1
        app.stat_vars['channels'].set(f'{total:,}')
        app.stat_vars['issues'].set(f'{issues:,}')
        app.stat_vars['logos'].set(f'{missing:,}')
        app.stat_vars['review'].set(f'{review:,}')
        app.stat_vars['new'].set(f'{new:,} / {backup:,}')
    except Exception:
        for k in getattr(app,'stat_vars',{}):app.stat_vars[k].set('—')


def _export_latest(app):
    data=getattr(app,'last_scan_report',None)
    if not data or not data.get('results'):
        messagebox.showinfo('Scan report','Run Scan links to create a report.',parent=app);return
    path=filedialog.asksaveasfilename(parent=app,defaultextension='.xlsx',initialfile='Playlist-Stream-Scan.xlsx',filetypes=[('Excel workbook','*.xlsx')])
    if not path:return
    try:
        from scan_report import export_excel
        export_excel(path,data);app.status.set(f'Excel report saved: {path}')
    except Exception as error:app.error(error)
