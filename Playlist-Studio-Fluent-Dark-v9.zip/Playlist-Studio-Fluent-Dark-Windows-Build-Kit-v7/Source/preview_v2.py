from playlist_studio import Studio
from playlist_core import Channel
from studio_extras import ScanWindow
from test_streams import Server
from http.server import ThreadingHTTPServer
from PIL import ImageGrab
from pathlib import Path
import time,threading,types
root=Path(__file__).parent;server=ThreadingHTTPServer(('127.0.0.1',0),Server);threading.Thread(target=server.serve_forever,daemon=True).start();app=Studio();app.geometry('1480x880+20+20');app.doc.name='My channel collection'
for group,names in [('Bangladesh',[('Bangla Television','/live'),('News Bangladesh','/dead'),('Music Bangladesh','/restricted')]),('Indian Bangla',[('Bengali Entertainment','/media'),('Bangla Cinema','/html')]),('Indian Movies',[('Movie World','/master')]),('International',[('Global News','/unknown')])]:
    cat=app.doc.ensure_category(group)
    for name,path in names:app.doc.channels.append(Channel(name,f'http://127.0.0.1:{server.server_port}{path}',cat,{'tvg-id':name.replace(' ','')+'.example'}))
app.saved=app.doc.fingerprint();app.refresh();app.update();app.table.selection_set(app.doc.channels[0].id);app.update();win=ScanWindow(app);win.start();end=time.monotonic()+10
while win.running and time.monotonic()<end:app.update();time.sleep(.05)
assert len(win.results)==7 and not win.running
win.lift();app.update();time.sleep(.2);app.update();ImageGrab.grab(bbox=(win.winfo_rootx(),win.winfo_rooty(),win.winfo_rootx()+win.winfo_width(),win.winfo_rooty()+win.winfo_height())).save(root/'scan-preview.png');win.close();app.lift();app.update()
cid=app.doc.channels[0].id;x,y,w,h=app.table.bbox(cid);start=types.SimpleNamespace(widget=app.table,y=y+h//2,x_root=app.table.winfo_rootx()+x+10,y_root=app.table.winfo_rooty()+y+h//2,state=0);app.drag_start(start,'channel');target=app.doc.categories[1].id;x,y,w,h=app.groups.bbox(target);app.drag_motion(types.SimpleNamespace(x_root=app.groups.winfo_rootx()+x+40,y_root=app.groups.winfo_rooty()+y+h//2));app.update();ImageGrab.grab(bbox=(app.winfo_rootx(),app.winfo_rooty(),app.winfo_rootx()+app.winfo_width(),app.winfo_rooty()+app.winfo_height())).save(root/'drag-preview.png');app.clear_drag();app.geometry('1120x680+20+20');app.update();app.play_selected();app.player.stop()
for _ in range(10):app.update();time.sleep(.05)
ImageGrab.grab(bbox=(app.winfo_rootx(),app.winfo_rooty(),app.winfo_rootx()+app.winfo_width(),app.winfo_rooty()+app.winfo_height())).save(root/'small-preview.png');app.destroy();server.shutdown();server.server_close();print('Scan window completed all 7 channels. Layout screenshots captured.')
