"""Compact, synchronized volume track for embedded and fullscreen controls."""
import tkinter as tk


class VolumeSlider(tk.Canvas):
    def __init__(self,parent,variable,command):
        super().__init__(parent,width=100,height=25,bg='#07171d',highlightthickness=0,cursor='hand2')
        self.variable=variable;self.command=command
        self.trace=variable.trace_add('write',lambda *_:self.redraw())
        self.bind('<Configure>',lambda e:self.redraw());self.bind('<Destroy>',self.cleanup)
    def redraw(self):
        self.delete('all');end=max(11,self.winfo_width()-10);x=10+(end-10)*max(0,min(100,self.variable.get()))/100
        self.create_line(10,12,end,12,fill='#29545e',width=4,capstyle='round')
        self.create_line(10,12,x,12,fill='#36e5d5',width=4,capstyle='round')
        self.create_oval(x-5,7,x+5,17,fill='#dcfffc',outline='')
    def set(self,value):
        value=max(0,min(100,float(value)));self.variable.set(value);self.command(value)
    def cleanup(self,event):
        if event.widget is self:self.variable.trace_remove('write',self.trace)
