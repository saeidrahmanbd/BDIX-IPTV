@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Playlist Studio 3.0 - Fluent Dark Builder

echo.
echo  Playlist Studio 3.0 - Fluent Dark
 echo ===================================
echo  Windows x64 single-file build
 echo.

where py >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python launcher ^(py^) was not found.
  echo Install 64-bit Python 3.12+ with Tk enabled, then run this again.
  pause
  exit /b 1
)
py -3 -c "import sys; assert sys.maxsize > 2**32 and sys.version_info >= (3,12); print(sys.version)"
if errorlevel 1 goto :fail

echo [1/5] Installing build dependencies...
py -3 -m pip install --upgrade Pillow openpyxl pyinstaller
if errorlevel 1 goto :fail

echo [2/5] Checking source...
py -3 -m compileall -q Source
if errorlevel 1 goto :fail

echo [3/5] Downloading and verifying VLC 3.0.23...
set "VLC_URL=https://download.videolan.org/pub/videolan/vlc/3.0.23/win64/vlc-3.0.23-win64.zip"
set "VLC_SHA256=992d19dbd0b8a7cde9167d2f7780b1ef6f92acc8a71acfa736101a21f35181e1"
if exist VLC.zip del /q VLC.zip
if exist VLC-TMP rmdir /s /q VLC-TMP
if exist VLC rmdir /s /q VLC
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%VLC_URL%' -OutFile '%~dp0VLC.zip'"
if errorlevel 1 goto :fail
powershell -NoProfile -ExecutionPolicy Bypass -Command "$h=(Get-FileHash -Algorithm SHA256 '%~dp0VLC.zip').Hash.ToLower(); if($h -ne '%VLC_SHA256%'){Write-Host '[ERROR] VLC SHA-256 mismatch.' -ForegroundColor Red; exit 1}; Write-Host 'VLC SHA-256 verified.'"
if errorlevel 1 goto :fail
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%~dp0VLC.zip' -DestinationPath '%~dp0VLC-TMP' -Force"
if errorlevel 1 goto :fail
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=Get-ChildItem -LiteralPath '%~dp0VLC-TMP' -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'libvlc.dll') } | Select-Object -First 1; if(-not $d){exit 1}; New-Item -ItemType Directory -Force -Path '%~dp0VLC' | Out-Null; Get-ChildItem -LiteralPath $d.FullName | Copy-Item -Destination '%~dp0VLC' -Recurse -Force"
if errorlevel 1 goto :fail
if not exist VLC\libvlc.dll goto :fail
if not exist VLC\libvlccore.dll goto :fail
rmdir /s /q VLC-TMP >nul 2>nul

echo [4/5] Building single-file executable...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "Playlist-Studio-3.0-Fluent-Dark.spec" del /q "Playlist-Studio-3.0-Fluent-Dark.spec"
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name "Playlist-Studio-3.0-Fluent-Dark" --add-data "VLC;VLC" Source\playlist_studio.py
if errorlevel 1 goto :fail
copy /y "dist\Playlist-Studio-3.0-Fluent-Dark.exe" "%~dp0Playlist-Studio-3.0-Fluent-Dark.exe" >nul
if errorlevel 1 goto :fail

echo [5/5] Build verification...
for %%F in ("%~dp0Playlist-Studio-3.0-Fluent-Dark.exe") do echo Built: %%~zF bytes

echo.
echo BUILD COMPLETE
echo EXE: %~dp0Playlist-Studio-3.0-Fluent-Dark.exe
echo.
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. Review the error above.
pause
exit /b 1
